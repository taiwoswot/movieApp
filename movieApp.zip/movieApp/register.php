<?php 
session_start();
require 'connect.php';  // Database connection
if (($_SERVER["REQUEST_METHOD"] == "POST") && !empty($_POST)) {
    // Get User details
    $name = ($_POST['uName']);
    $userEmail = ($_POST['email']);
    $dob = ($_POST['dob']);
    $userPwd = password_hash($_POST['pwd'], PASSWORD_DEFAULT);
    $today = date('Y-m-d');

    if (filter_var($userEmail, FILTER_VALIDATE_EMAIL)) { // Validate the email
        // First check if user exist already
        $check = $db->prepare("SELECT email FROM `users` WHERE email = ?");
        $check->execute([$userEmail]);

        if ($check->rowCount() == 0) {
            // Now enter the details
            $newUser = $db->prepare("INSERT INTO `users` (user_name, email, dob, user_password, user_role, reg_date) VALUES (?, ?, ?, ?, ?, ?)");
            $newUser->execute([$name, $userEmail, $dob, $userPwd, 'user', $today]);
            
            if ($newUser->rowCount() == 1) {
                $_SESSION['userEmail'] = $userEmail;
                $_SESSION['userName'] = $name;
                $_SESSION['role'] = 'user';
                $_SESSION['LoggedInStatus'] = 1; // Needed to show or hide the user image

                $smsg = 'Registration Successful';
                header("refresh:3; url=index.php");

            } else if ($newUser->rowCount() == 0) {
                $fmsg = "Registration Successful";
            }
        } else {
            $fmsg = "Record exist for this user";
        }
	} else {
        $fmsg = "Invalid Email Format";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<?php require 'general/links.php'; ?>
</head>
<body>
    <div class="container-fluid" id="register-page">
        <div class="row">
            <?php if(isset($smsg)){ ?>
                <div class="alert alert-success" style="cursor:pointer; margin-left:auto; margin-right:auto; width: 50%;" onclick="$(this).fadeOut();"> 
                    <?php echo $smsg;?>
                </div>
            <?php } ?>
            <?php if(isset($fmsg)){ ?>
                <div class="alert alert-danger" style="cursor:pointer; margin-left:auto; margin-right:auto; width: 50%;" onclick="$(this).fadeOut();"> 
                    <?php echo $fmsg;?>
                </div>
            <?php } ?>
        </div>
        <div class="row">
            <div class="col sm-12">
                <form action="" method="post">
                    <a href="index.php"><i class="fa fa-home"></i></a>
                    <div class="form-group">
                        <label for="Name">Name</label>
                        <input type="text" name="uName" placeholder="your full name" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="Email">Email</label>
                        <input type="email" name="email" placeholder="your email" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="Date of Birth">Date of Birth</label>
                        <input type="date" name="dob" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="Password">Password</label>
                        <input type="password" name="pwd" placeholder="your password" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block">Register</button>
                    <p>Have an account already? <span class="loginBtn"><a href="login.php">Login</a></span></p>
                </form>
            </div>
        </div>
    </div>
</body>
</html>