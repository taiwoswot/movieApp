<section class="container-fluid" id="sec1">
    <div class="row">
        <div class="col-sm-5">
            <h2>Unlimited movies <br> Unending entertainment</h2>
            <p>All you movie collections</p>
            <a href="register.php"><button class="btn btn-primary joinNow">Join Now - free</button></a>
            <p>Have an account? <span class="loginBtn"><a href="login.php">Log in</a></span></p>
        </div>
        <div class="col-sm-7">
            <img src="assets/img/sec1_img1.jpeg" class="rounded-circle sec1Imgs sec1Imgs_1" alt="">
            <img src="assets/img/sec1_img2.jpeg" class="rounded-circle sec1Imgs sec1Imgs_2" alt="">
            <img src="assets/img/sec1_img3.jpeg" class="rounded-circle sec1Imgs sec1Imgs_3" alt="">
        </div>
    </div>
</section>