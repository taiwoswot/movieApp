<?php
	try {
		// Connect to Database with PDO Object
		$db = new PDO('mysql:host=localhost; dbname=movieApp; charset=utf8mb4', "root", "", [PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);

		// Select all movies
		$getMovies = $db->prepare("SELECT * FROM movies");
		$getMovies->execute(); 

		// Select all subscriptions
		$getSubscriptions = $db->prepare("SELECT * FROM subscription ORDER BY subscribed_date DESC");
		$getSubscriptions->execute(); 

		// Select all users
		$getUsers = $db->prepare("SELECT * FROM users");
		$getUsers->execute(); 
	} catch (PDOException $e) {
		// If Connection fails, show PDO error
		echo "Error Connecting to MySql: " . $e->getMessage();
	}
?>