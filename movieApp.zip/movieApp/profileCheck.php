<?php
session_start();
if (($_SESSION['role']) == 'user') {
    header('Location: user/index.php');
} else if (($_SESSION['role']) == 'admin') {
    header('Location: admin/index.php');
} else {
    header('Location: index.php');
}
?>