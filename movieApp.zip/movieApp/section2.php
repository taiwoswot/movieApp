<section class="container-fluid" id="sec2">
    <div class="row moviesSectionHeading">
        <div class="col-sm-12">
            <h4>New Releases</h4>
        </div>
    </div>
    <div class="row moviesSection">
        <?php   
            if ($getMovies->rowCount() > 0) {
                while ($row = $getMovies->fetch(PDO::FETCH_ASSOC)) {
                    $id =  $row['movie_id'];
                    $title =  $row['movie_title'];
                    $excerpt =  $row['movie_excerpt'];
                    $genre =  $row['movie_genre'];
                    $price =  $row['movie_price'];
                    $trailer =  $row['movie_trailer'];
                    $banner =  $row['movie_banner'];
                    $video =  $row['movie_video'];
                    $pg =  $row['movie_pg'];
                    $year =  $row['movie_year'];
                    $rating =  $row['movie_rating'];
            
                    echo '<div class="col-sm-3">
                        <div><img src="admin/uploads/banners/'.$banner.'"></div>
                        <div class="movDetails">
                            <video controls><source src="admin/uploads/trailers/'.$trailer.'" type="video/mp4"></video>
                            <div class="movText" id="'.$id.'">
                                <div class="buy" id="'.$price.'">Buy: $'.$price.' <span class="addToCart"><i class="fa fa-dollar-sign"></i> <i class="fa fa-heart"></i></span></div>
                                <h6>'.$title.'</h6>
                                <p>'.substr($excerpt, 0, 100).' . . .</p>
                                <p style="display:none;">'.$rating.' &nbsp; &nbsp; | '.$year.'</p>
                                <p class="pg">PG: '.$pg.'</p>
                            </div>
                        </div>
                    </div>';
                }
            } else {
                echo '<div class="col-sm-12 text-center">No movies yet</div>';
            }
        ?>
    </div>
</section>
