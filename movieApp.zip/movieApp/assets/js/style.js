$(document).ready(function() {
    $('.fa-times-circle').click(function() {
        $(this).closest('.container-fluid').fadeOut();
    });

    /* ***************************************
        LOG OUT FROM INDEX PAGE
    **************************************** */
    $('.logOut').click(function(event) {
        event.preventDefault();
        location.href = "logout.php";
    });

    /* ***************************************
        ALL SUBSCRIBER - SUBSCRIPTION PAGE 
    **************************************** */
    // Fetch all movies
    $('.allSubscriber').click(function() {
            var con = 'all-movie-subscribers';
            $.post('process.php', {constant:con}, function(data) {
                $('#subsciptionContainer').html(data);
            });
    });

    /* ***************************************
        ADMIN SUBSCRIPTION PAGE 
    **************************************** */
    $('.goSubscriber').click(function() {
        var subName = $('.subscrName').val();
        var movTitle = $('.subscrMovTitle').val();
        var movMonth = $('.subscrMovMonth').val();

        // If none of the field is entered
        if ((subName == "") && (movTitle == "") && (movMonth == "")) {
            alert('Select a criteria to search');
        } 

        // Searching by Movie Name
        if (subName !== "") {
            var con = 'search-by-sub-name';
            $.post('process.php', {subName:subName, constant:con}, function(data) {
                $('#subsciptionContainer').html(data);
            });
        } else

        // Searching by Movie Title
        if (movTitle !== "") {
            var con = 'search-by-movie-title';
            $.post('process.php', {movTitle:movTitle, constant:con}, function(data) {
                $('#subsciptionContainer').html(data);
            });
        }

        // Searching by Month
        if (movMonth !== "") {
            var con = 'search-by-sub-month';
            $.post('process.php', {movMonth:movMonth, constant:con}, function(data) {
                $('#subsciptionContainer').html(data);
            });
        }
    });

    /* ***************************************
        USERS MY INDEX (MY MOVIES) PAGE
    **************************************** */
    $('#toggMovies').change(function() {
        var togView = $(this).val();
        var con = 'user-subscribed-or-cart';
        $.post('userProcess.php', {constant:con, togView:togView}, 
            function(data) {
                $('#tableCont').html(data);
        });
    })

    /* ***************************************
        ADMIN SEARCH FOR USERS STARTS HERE
    **************************************** */
    // Details Button of users
    $(document).on('click', '.checkUser', function() {
        var userEmail = $(this).closest('tr').attr('id');
        location.href = "users-details.php?email="+userEmail;
    });

    // Fetch all users
    $('.all-user').click(function() {
        var con = 'all-user';
        $.post('process.php', {constant:con}, function(data) {
            $('#userDet').html(data);
        });
    });

    // Details Search of users
    $('.goSearchUser').click(function() {
        var minAge = $('#minAge').val();
        var maxAge = $('#maxAge').val();
        var nameUser = $('#nameUser').val();

        // If none of the field is entered
        if ((minAge == "") && (maxAge == "") && (nameUser == "")) {
            alert('Select a criteria to search');
        } 

        // Searching by Minimum Age
        if (minAge !== "") {
            var con = 'min';
            $.post('process.php', {age:minAge, constant:con}, function(data) {
                $('#userDet').html(data);
            });
        } else

        // Searching by Maximum Age
        if (maxAge !== "") {
            var con = 'max';
            $.post('process.php', {age:maxAge, constant:con}, function(data) {
                $('#userDet').html(data);
            });
        }
    });
    /* *******************************************
        ADMIN SEARCH FOR MOVIES STARTS HERE
    ******************************************** */
   // Fetch by Genre
   $('.goMovies').click(function() {
        var genre = $('#genre').val();
        var lastLetter = $('#lastLetter').val();

        // If none of the field is entered
        if ((genre == "") && (lastLetter == "")) {
            alert('Select a criteria to search');
        } 

        // Search by Genre
        if (genre !== "") {
            var con = 'genre';
            $.post('process.php', {gen:genre, constant:con}, function(data) {
                $('#movie-cont').html(data);
            });
        }

        // Search by Last letter of movie title
        if (lastLetter !== "") {
            var con = 'lastLetter';
            $.post('process.php', {lastL:lastLetter, constant:con}, function(data) {
                $('#movie-cont').html(data);
            });
        } 
   });

   // Fetch all movies
   $('#allMovies').click(function() {
        var con = 'all-movies';
        $.post('process.php', {constant:con}, function(data) {
            $('#movie-cont').html(data);
        });
   });

   // See Details of each Movies
   $(document).on('click', '.seeMDetails', function() {
        var movieID = $(this).closest('tr').attr('id');
        location.href = "moviesDetails.php?mid="+movieID;
   });
    /*
    // Prevent the Login page default anchor function
    $('.loginBtn').click(function(event) {
        event.preventDefault();
        $('#login-page').fadeIn();
    });

    // Prevent the Register page default anchor function
    $('.joinNow').click(function(event) {
        event.preventDefault();
        $('#register-page').fadeIn();
    }); */

    // For user to edit its profile
    $('.edit').click(function() {
        $(this).closest('form').find('input').prop('disabled', true); // Disable all input fields
        $(this).closest('form').find('.done').hide();  // hide all done options
        $(this).closest('form').find('.edit').show(); // Show all edit options
        $(this).closest('.form-group').find('input').prop('disabled', false);   // Enable the input option for only this one
        $(this).closest('.form-group').find('.done').show();   // Enable the done option for only this one
        $(this).closest('.form-group').find('.edit').hide();   // Enable the done option for only this one
    });

    // For user to edit its password
    $('.edit-pwd').click(function() {
        $(this).closest('.form-group').hide();   // Enable the done option for only this one
        $('.change-password').show();   // Enable the done option for only this one
        $('.change-password .done').show();   // Enable the done option for only this one
        $('.change-password input').prop('disabled', false);  // Enable the done option for only this one
    });

    // For user to cancel edit password option
    $('.cancel-pwd').click(function() {
        $('.dPwd').show();
        $('.change-password').hide();  
    });

    // Trigger Banner Upload
    $('#uploadBanner').click(function() {
        $('.bannerToUpload').trigger('click');
    });
    // Main Banner Upload
    $('.bannerToUpload').on('change', function() {
        var property = (this).files[0];
        var image_name = property.name;
        var image_extension = image_name.split('.').pop().toLowerCase();
        
        if (jQuery.inArray(image_extension, ['gif', 'png', 'jpg', 'jpeg']) == -1) {
            alert("Invalid Image File");
        }
        var image_size = property.size;
        if (image_size > 2000000){
            alert("Image File Size cannot be more than 2MB");
        }
        else {
            var form_data = new FormData();
            form_data.append("file", property);
            $.ajax({
                url:"uploads/banner-to-upload.php",
                method:"POST",
                data:form_data,
                contentType:false,
                cache:false,
                processData:false,
                beforeSend:function() {
                    $(".loader-banner").show();
                },
                success:function(result) {
                    var data_x = result.split("||::");
                    if (data_x[0] == "1") {
                        $('.bannerToUpload').val('');   // empty the image div
                        // Create the Inner Image
                        var ImageElement = document.createElement('img');
                        ImageElement.src = 'uploads/banners/'+data_x[1];
                        // Append the new banner to the div
                        $('#bannerImg').html(ImageElement);
                        $(".loader-banner").hide();                        
                    } else {
                        $('.bannerToUpload').val('');
                        $(".loader-banner").hide();  
                        //alert(data_x[1]);
                        alert(data_x[1]);
                    }
                }
            });
        }
    });

    // Trigger Trailer Upload
    $('#uploadTrailer').click(function() {
        $('.trailerToUpload').trigger('click');
    });
    // Main Trailer Upload
    $('.trailerToUpload').on('change', function() {
        var property = (this).files[0];
        var image_name = property.name;
        var image_extension = image_name.split('.').pop().toLowerCase();
        
        if (jQuery.inArray(image_extension, ['mp4']) == -1) {
            alert("Invalid Image File");
        }
        var image_size = property.size;
        if (image_size > 50000000){
            alert("Image File Size cannot be more than 50MB");
        }
        else {
            var form_data = new FormData();
            form_data.append("file", property);
            $.ajax({
                url:"uploads/trailer-to-upload.php",
                method:"POST",
                data:form_data,
                contentType:false,
                cache:false,
                processData:false,
                beforeSend:function() {
                    $(".loader-trailer").show();
                },
                success:function(result) {
                    var data_x = result.split("||::");
                    if (data_x[0] == "1") {
                        $('.trailerToUpload').val('');   // empty the image div
                        // Create the Video container
                        var videoElement = document.createElement('video');
                        videoElement.setAttribute('controls', 'controls');
                        // Create the Video source element
                        var videoSource = document.createElement('source');
                        videoSource.src = 'uploads/trailers/'+data_x[1];
                        videoSource.type = "video/mp4";
                        // Append the new banner to the div
                        videoElement.append(videoSource);
                        $('#TrailerImg').html(videoElement);
                        $(".loader-trailer").hide();                        
                    } else {
                        $('.trailerToUpload').val('');
                        $(".loader-trailer").hide();  
                        //alert(data_x[1]);
                        alert(result);
                    }
                }
            });
        }
    });

    // Trigger Full Video Upload
    $('#uploadFullVideo').click(function() {
        $('.fullVideoToUpload').trigger('click');
    });
    // Main Full Video Upload
    $('.fullVideoToUpload').on('change', function() {
        var property = (this).files[0];
        var image_name = property.name;
        var image_extension = image_name.split('.').pop().toLowerCase();
        
        if (jQuery.inArray(image_extension, ['mp4']) == -1) {
            alert("Invalid Image File");
        }
        var image_size = property.size;
        if (image_size > 1500000000){
            alert("Image File Size cannot be more than 1.5GB");
        }
        else {
            var form_data = new FormData();
            form_data.append("file", property);
            $.ajax({
                url:"uploads/video-to-upload.php",
                method:"POST",
                data:form_data,
                contentType:false,
                cache:false,
                processData:false,
                beforeSend:function() {
                    $(".loader-full").show();
                },
                success:function(result) {
                    var data_x = result.split("||::");
                    if (data_x[0] == "1") {
                        $('.fullVideoToUpload').val('');   // empty the image div
                        // Create the Video container
                        var videoElement = document.createElement('video');
                        videoElement.setAttribute('controls', 'controls');
                        // Create the Video source element
                        var videoSource = document.createElement('source');
                        videoSource.src = 'uploads/videos/'+data_x[1];
                        videoSource.type = "video/mp4";
                        // Append the new banner to the div
                        videoElement.append(videoSource);
                        $('#fullVideoImg').html(videoElement);
                        $(".loader-full").hide();                        
                    } else {
                        $('.fullVideoToUpload').val('');
                        $(".loader-full").hide();  
                        //alert(data_x[1]);
                        alert(result);
                    }
                }
            });
        }
    });
});
    