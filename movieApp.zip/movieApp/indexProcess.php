<?php
session_start();
require 'connect.php';  // Database connection
$constant = $_POST['constant'];

/* ********************************
    // Add to Cart
***********************************/
if ($constant == "add-to-cart") {
    $movieID = $_POST['mID'];
    $movieTitle = $_POST['mTitle'];
    $user_email = $_SESSION['userEmail'];
    $price = $_POST['mPrice'];
    $date = date('Y-m-d');

    // Update the cart table
    $insertCart = $db->prepare("INSERT INTO `cart` (user_email, movie_id, movie_title, price, cart_date) VALUES (?, ?, ?, ?, ?)");
    $insertCart->execute([$user_email, $movieID, $movieTitle, $price, $date]);
    if (($insertCart->rowCount()) == 1) {
        // Now count the number of items in cart for this particular user
        $check = $db->prepare("SELECT * FROM `cart` WHERE user_email = ?");
        $check->execute([$user_email]);
        $count = $check->rowCount();
        echo $count;
    } else {
        echo "0";
    }
} else

/* ********************************
    // Buy Movie (One movie)
***********************************/
if ($constant == "buy-one-movie") {
    $movieID = $_POST['mID'];
    $movieTitle = $_POST['mTitle'];
    $email = $_SESSION['userEmail'];
    $name = $_SESSION['userName'];
    $price = $_POST['mPrice'];
    $date = date('Y-m-d');
    $month = date('F');

    // First Check if user has subscribed for the movie
    $checkSirst = $db->prepare("SELECT * FROM `subscription` WHERE subscriber_email = ? AND movie_id = ?");
    $checkSirst->execute([$email, $movieID]);
    $countFirst = $checkSirst->rowCount();
    if ($countFirst > 0) {
        echo '03|::|You have already bought this movie';
    } else {
        // Update the subscription table
        $insertSubTable = $db->prepare("INSERT INTO `subscription` (movie_id, movie_title, subscriber_email, subscriber_name, subscribed_date, subscribed_month, price, payment_ref) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $insertSubTable->execute([$movieID, $movieTitle, $email, $name, $date, $month, $price, 'x123abc']);
        if (($insertSubTable->rowCount()) == 1) {
            // Check if the newly subscribed movie is in cart and remove it if yes
            $confFromCart = $db->prepare("SELECT * FROM `cart` WHERE user_email = ? AND movie_id = ?");
            $confFromCart->execute([$email, $movieID]);
            if (($confFromCart->rowCount()) >= 1) {
                // Proceed to delete it from cart
                $delFromCart = $db->prepare("DELETE FROM `cart` WHERE user_email = ? AND movie_id = ?");
                $delFromCart->execute([$email, $movieID]);

                // Now count the number of remaining items in cart for the user
                $checkCartAgain = $db->prepare("SELECT * FROM `cart` WHERE user_email = ?");
                $checkCartAgain->execute([$email]);
                $countCartAgain = $checkCartAgain->rowCount();

                echo '01|::|Subscription successful|::|'.$countCartAgain;
            } else {
                echo '02|::|Subscription successful';
            }
        } else {
            echo '00|::|Subscription Failed';
        }
    }
}
?>