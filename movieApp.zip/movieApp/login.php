<?php 
session_start();
require 'connect.php';  // Database connection
if (($_SERVER["REQUEST_METHOD"] == "POST") && !empty($_POST)) {
    // Get User details
	$userEmail = ($_POST['email']);
    $userPwd = ($_POST['pwd']);
    $today = date('Y-m-d');

	if (filter_var($userEmail, FILTER_VALIDATE_EMAIL)) { // Validate the email
		$check = $db->prepare("SELECT email, user_password, user_name, user_active, user_role FROM `users` WHERE email = ?");
        $check->execute([$userEmail]);
        
        if ($check->rowCount() == 1) {
            while ($rowCheck = $check->fetch(PDO::FETCH_ASSOC)) {
                $email =  $rowCheck['email'];
                $pwdHash = $rowCheck['user_password'];
                $status = $rowCheck['user_active'];
                $role = $rowCheck['user_role'];
                $user_name = $rowCheck['user_name'];
            }

            if (password_verify($userPwd, $pwdHash)) {
                // Update the Last Login time
                $updLastLogin = $db->prepare("UPDATE `users` SET last_login = ? WHERE email = ?");
                $updLastLogin->execute([$today, $userEmail]);

                $_SESSION['userEmail'] = $userEmail;
                $_SESSION['userName'] = $user_name;
                $_SESSION['role'] = $role;
                $_SESSION['LoggedInStatus'] = 1; // Needed to show or hide the user image

                header('Location: index.php');
            } else {
                $fmsg = 'Wrong Password!';
            }
        } else {
            $fmsg = "Wrong/Invalid Email Address";
        }
	} else {
        $fmsg = "Invalid Email Format";
    }
}
?>
<!DOCTYPE html>
<head>
	<?php require 'general/links.php'; ?>
</head>
<body>
    <div class="container-fluid" id="login-page">
        <div class="row">
            <?php if(isset($fmsg)){ ?>
                <div class="alert alert-danger" style="cursor:pointer; margin-left:auto; margin-right:auto; width: 50%;" onclick="$(this).fadeOut();"> 
                    <?php echo $fmsg;?>
                </div>
            <?php } ?>
        </div>
        <div class="row">
            <div class="col sm-12">
                <form method="post">
                    <a href="index.php"><i class="fa fa-home"></i></a>
                    <div class="form-group">
                        <label for="Email">Email</label>
                        <input type="email" name="email" placeholder="your email" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="Password">Password</label>
                        <input type="password" name="pwd" placeholder="your password" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block">Login</button>
                    <p>Don't have an account? <span class="registerBtn"><a href="register.php">Register</a></span></p>
                </form>
            </div>
        </div>
    </div>
</body>