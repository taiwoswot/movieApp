<section class="container-fluid" id="footer">
    <div class="container-fluid">
        <div class="col-sm-12">
            <h5>CONNECT</h5>
            <a href="https://facebook.com/lagos90daysscripturechallenge" target="_blank"><i class="fab fa-facebook"></i></a>
            <a href="https://instagram.com/lagos90daysscripturechallenge" target="_blank"><i class="fab fa-instagram"></i></a>
            <a href="https://twitter.com/lagos90daysscripturechallenge" target="_blank"><i class="fab fa-twitter"></i></a>
            <a href=""><i class="fa fa-envelope"></i></a>
            <a href="https://www.youtube.com/channel/UC2U-GiSdgqKZSF-ndR6TaHA" target="_blank"><i class="fab fa-youtube"></i></a>
        </div>
        <hr>
        <div class="col-sm-12 text-center">
            <p>Copyright 2021.</p>
        </div>
    </div>
</section>