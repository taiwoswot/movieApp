<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="Movies | Action | Adventure">
<meta name="author" content="">
<title>Movie App</title>
<link rel="icon" href="assets/img/logo.png" sizes="16x16" type="image/png">
<!-- JS -->
<script src="assets/js/jquery.js"></script> <!-- JQUERY -->
<script src="assets/bootstrap/js/bootstrap.js"></script> <!-- BOOTSTRAP -->
<script src="assets/owlcarousel/owl.carousel.min.js"></script> <!-- OWLCAROUSEL -->
<script src="assets/js/style.js"></script> <!-- JQUERY -->

<!-- CSS -->
<link rel="stylesheet" href="assets/fontawesome/css/all.css">   <!-- FONTAWESOME -->
<link href="assets/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet"> <!-- OWLCAROUSEL -->
<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.css">   <!-- BOOTSTRAP -->
<link href="style.css" rel="stylesheet">
