
    <section class="container-fluid" id="large-device-menu">
        <div class="row">
            <div class="col-sm-12">
                <div class="logo">
                    <img src="assets/img/logo.png" alt="">
                </div>
                <div class="cont">
                    <span id="leftMenus">
                        <a href="#">Explore <hr></a>
                        <a href="profileCheck.php">My movies <hr></a>
                    </span>
                    <span id="rightMenus">
                        <a href="profileCheck.php"><i class="fa fa-shopping-cart"></i> <span class="cartCount"><span class="cartInner"><?php echo $count;?></span></span></a>
                        <a href="login.php" class="loginBtn">Login <hr></a>
                        <a href="register.php" class="joinNow">Join Now</a>
                    </span>
                    <span id="rightMenusIn">
                        <a href="profileCheck.php"><i class="fa fa-shopping-cart"></i> <span class="cartCount"><span class="cartInner"><?php echo $count;?></span></span></a>
                        <a href="profileCheck.php"><i class="fa fa-bars"></i></a>
                        <a href="#"><img src="assets/img/user.png" class="circle-image" alt=""> <span class="uname"><?php echo $_SESSION['userName']; ?> <br><span class="logOut">Log out</span></span></a>
                    </span>
                </div>
            </div>
        </div>
    </section>