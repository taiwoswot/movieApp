<section class="container-fluid" id="sec3">
    <div class="row text-center">
        <div class="col-sm-12">
            <h3>FREQUENTLY ASKED QUESTIONS (FAQs)</h3>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-12">
            <p class="faqs">Is is free to use MovieDom Anywhere? <i class="fa fa-plus"></i></p>
            <p class="faqs">Can I purchase movies MovieDom Anywhere? <i class="fa fa-plus"></i></p>
            <p class="faqs">Can I watch my movies on MovieDom from any device? <i class="fa fa-plus"></i></p>
            <p class="faqs">Can I download movies for offline watch on MovieDom? <i class="fa fa-plus"></i></p>
        </div>
    </div>
    <div class="row text-center bbc">
        <div class="col-sm-12">
            <p>Brought to you by MovieDom Studios and Collections</p>
            <a href="register.php"><button class="btn btn-primary joinNow">Join Now - free</button></a>
            <p>Have an account? <span class="loginBtn"><a href="login.php">Log in</a></span></p>
        </div>
    </div>
    <footer class="row text-center">
        <div class="col-sm-12">
            <p><a href="#">Explore</a>  |  <a href="#">My movies</a></p>
        </div>
    </footer>
</section>