<?php
session_start();
require 'connect.php';  // Database connection 
if ((isset($_SESSION['LoggedInStatus'])) && ($_SESSION['LoggedInStatus'] == 1)) {
    $loggedInStatus = 1;

    // Now count the number of items in cart for this particular user (if any)
    $checkCart = $db->prepare("SELECT * FROM `cart` WHERE user_email = ?");
    $checkCart->execute([$_SESSION['userEmail']]);
    $count = $checkCart->rowCount() ? $checkCart->rowCount() : 0;

} else {
    $loggedInStatus = 0;
    $count = 0;
}
?>
<!DOCTYPE html>
<head>
	<?php require 'general/links.php'; ?>
</head>
<body>
    <div id="index-page"> 
        <?php
            include 'general/menu.php';
            include 'section1.php';
            include 'section2.php';
            include 'section3.php';
        ?>
    </div>
    <script>
        var logedInS = "<?php echo $loggedInStatus; ?>";
        //alert(logedInS);
        if (logedInS == 1) {
            $('#rightMenusIn').show();
            $('#rightMenus').hide();
            $('.xxx').hide();
        } else {
            $('#rightMenusIn').hide();
            $('#rightMenus').show();
        }

        // To buy directly
        $('.fa-dollar-sign').click(function() {
            if (logedInS != 1) {
                alert('Please log in to Buy Movie');
            } else {
                var conf = confirm('Proceed to subscribe for the selected movie?');
                if (conf === true) {
                    var movieSelected = $(this).closest('.movText').attr('id'); // ID of the movie
                    var movieTitle = $(this).closest('.movText').find('h6').text(); // Title of the movie
                    var moviePrice = $(this).closest('.movText').find('.buy').attr('id'); // Price of the movie
                    var con = 'buy-one-movie';
                    $.post('indexProcess.php', {constant:con, mID:movieSelected, mTitle:movieTitle, mPrice:moviePrice}, function(data) {
                        var result = data.split('|::|');
                        //alert(data);
                        ///*
                        if ((result[0]) == '01') { 
                            // Reset the cart item number if applicable
                            $('.cartInner').text(result[2]);
                            alert(result[1]);
                        } else {
                            alert(result[1]);
                        } //*/
                    });
                }
            }
        });
        // To add to cart
        $('.fa-heart').click(function() {
            if (logedInS != 1) {
                alert('Please log in to add Movie to cart');
            } else {
                var movieSelected = $(this).closest('.movText').attr('id'); // ID of the movie
                var movieTitle = $(this).closest('.movText').find('h6').text(); // Title of the movie
                var moviePrice = $(this).closest('.movText').find('.buy').attr('id'); // Price of the movie
                var con = 'add-to-cart';
                $.post('indexProcess.php', {constant:con, mID:movieSelected, mTitle:movieTitle, mPrice:moviePrice}, function(data) {
                    if (data >= 1) {
                        $('.cartInner').text(data);
                        alert('Movie ' + movieTitle + ' addedd successfully');
                    } else {
                        alert('Unable to add ' + movieTitle + ' to cart');
                    }
                });
            }
        });
    </script>
</body>