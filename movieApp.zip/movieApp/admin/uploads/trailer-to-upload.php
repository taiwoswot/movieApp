<?php
session_start();
    require '../../connect.php';
	if ($_FILES["file"]["name"] != '') {
        $image_name = $_FILES["file"]["name"];
		$check = getimagesize($_FILES["file"]["tmp_name"]);
		
		$test = explode(".", $_FILES["file"]["name"]);
		$extension = end($test);
        $name = $image_name;
        $location = "trailers/".$name;
        
        // Check if a doc with the same name exists
        $check = $db->prepare("SELECT * FROM `movies` WHERE movie_trailer = ?");
        $check->execute([$name]);
        $count = $check->rowCount();
        if ($count >= 1) {
            echo("3||::Banner with this name exist already.");
		    exit;
        } else {
            move_uploaded_file($_FILES["file"]["tmp_name"], $location);
        }
	} else {
		echo("0||::No Banner Image Selected");
		exit;
    }
    
    if (isset($_SESSION['tmp_upl_id'])) {
        $updateURL = $db->prepare("UPDATE `movies` SET movie_trailer = ? WHERE tmp_upl_id = ?");
        $updateURL->execute([$name, 10]);
    } else {
        $updateURL = $db->prepare("INSERT INTO `movies` (movie_trailer, tmp_upl_id) VALUES (?, ?)");
        $updateURL->execute([$name, 10]);
    }
	
    if ($updateURL) {
        $_SESSION['trailerUrl'] = $name;
        if (!isset($_SESSION['tmp_upl_id'])) {
            $_SESSION['tmp_upl_id'] = 10;
        }
        echo '1||::'.$name;
    } else {
        echo '2||::ERROR UPD-004';
    }
?>