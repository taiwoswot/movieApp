<?php require '../connect.php';  // Database connection ?>
<!DOCTYPE html>
<head>
    <script src="../assets/js/jquery.js"></script>
    <script src="../assets/js/style.js"></script>
    <link href="../style.css" rel="stylesheet">
</head>
<body>
    <div id="user-dashboard-page"> 
        <section>
            <div class="leftCol">
                <img src="../assets/img/logo.png" alt="">
                <hr>
                <a href="index.php">My Movies</a>
                <hr>
                <a href="users.php">Users</a>
                <hr>
                <a href="subscription.php">Subscriptions</a>
                <hr>
                <a href="movies.php" class="userNav">Movies</a>
                <hr>
                <a href="profile.php">My Profile</a>
                <hr>
                <a href="history.php">History</a>
                <hr>
                <div id="groupCallAdmin">
                    <a href="../index.php">Home Page</a>
                    <a href="../logout.php">Log Out</a>
                </div>
            </div>
            <div class="rightCol">
                <div class="options">
                    <a href="movies.php"><button>Go back</button></a>
                    <button class="all">All</button>
                    <input type="number" placeholder="search by month" class="month">
                    <button class="go">Go</button>
                </div>
                <div class="table">
                    <?php
                        if ($getSubscriptions->rowCount() > 0) {
                            $serial = 1;
                            echo '<table>
                                    <tr><th>
                                        <td>S/N</td>
                                        <td>Name</td>
                                        <td>Movie Title</td>
                                        <td>Price</td>
                                        <td>Date</td>
                                        <td>Month</td>
                                    </th></tr>';
                                while ($row = $getSubscriptions->fetch(PDO::FETCH_ASSOC)) {
                                    $subscriber_name =  $row['subscriber_name'];
                                    $title =  $row['movie_title'];
                                    $price =  $row['price'];
                                    $date =  $row['subscribed_date'];;
                                    $month =  'subscribed_month';
                            
                                    echo '<tr>
                                        <td>'.$serial.'</td>
                                        <td>'.$subscriber_name.'</td>
                                        <td>'.$title.'</td>
                                        <td>'.$price.'</td>
                                        <td>'.$date.'</td>
                                        <td>'.$month.'</td>
                                    </tr>';

                                    $serial++;
                                }
                            echo '</table>';
                        } else {
                            echo '<div>No subscriber record found</div>';
                        }
                    ?>
                </div>
            </div>
        </section>
    </div>
    <script>
        $('.userNav').css('background', '#575664');
    </script>
</body>