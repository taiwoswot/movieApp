<?php
require '../connect.php';  // Database connection 
function userAge($dob, $today) {
    $d1 = explode("-", $dob);
    $d2 = explode("-", $today);
    $former = $d1[0];
    $later = $d2[0];

    return ($later - $former);
}
?>
<!DOCTYPE html>
<head>
    <script src="../assets/js/jquery.js"></script>
    <script src="../assets/js/style.js"></script>
    <link href="../style.css" rel="stylesheet">
</head>
<body>
    <div id="user-dashboard-page"> 
        <section>
            <div class="leftCol">
                <img src="../assets/img/logo.png" alt="">
                <hr>
                <a href="index.php">My Movies</a>
                <hr>
                <a href="#" class="userNav">Users</a>
                <hr>
                <a href="subscription.php">Subscriptions</a>
                <hr>
                <a href="movies.php">Movies</a>
                <hr>
                <a href="profile.php">My Profile</a>
                <hr>
                <div id="groupCallAdmin">
                    <a href="../index.php">Home Page</a>
                    <a href="../logout.php">Log Out</a>
                </div>
            </div>
            <div class="rightCol">
                <div class="options">
                    <button class="all-user btn-primary">All</button>
                    <input type="number" placeholder="search by min age (inclusive)" id="minAge" class="allUsersSearchVal inputs">
                    <input type="number" placeholder="search by max age (inclusive)" id="maxAge" class="allUsersSearchVal inputs">
                    <button class="goSearchUser btn-primary">Go</button>
                </div>
                <div id="userDet">
                    <table>
                        <?php
                            if ($getUsers->rowCount() > 0) {
                                $today = date('Y-m-d'); // today
                                $serial = 1;
                                echo '<table>
                                        <tr>
                                            <th>S/N</th>
                                            <th>Pics</th>
                                            <th>Name</th>
                                            <th>Reg Date</th>
                                            <th>Last Login</th>
                                            <th>Age</th>
                                            <th>Details</th>
                                        </tr>';
                                    while ($row = $getUsers->fetch(PDO::FETCH_ASSOC)) {
                                        $email =  $row['email'];
                                        $pics =  $row['pics'];
                                        $name =  $row['user_name'];
                                        $reg_date =  $row['reg_date'];
                                        $last_login =  $row['last_login'];
                                        $dob =  $row['dob'];
                                
                                        echo '<tr id="'.$email.'">
                                            <td>'.$serial.'</td>
                                            <td>'.$pics.'</td>
                                            <td>'.$name.'</td>
                                            <td>'.$reg_date.'</td>
                                            <td>'.$last_login.'</td>
                                            <td>'.userAge($dob, $today).'</td>
                                            <td class="btn-primary checkUser">Details</td>
                                        </tr>';

                                        $serial++;
                                    }
                                echo '</table>';
                            } else {
                                echo '<h1>No User found</h1>';
                            }
                        ?>
                    </table>
                </div>
            </div>
        </section>
    </div>
    <script>
        $('.userNav').css('background', '#575664');
    </script>
</body>