<?php
session_start();
require '../connect.php';  // Database connection
if ((isset($_SESSION['bannerUrl'])) && (!empty($_SESSION['bannerUrl']))) {
    $bannerUrl = '<img src="uploads/banners/'.$_SESSION['bannerUrl'].'" alt="">';
} else {
    $bannerUrl = '<img src="../assets/img/banner.jpeg" alt="">';
}

if ((isset($_SESSION['trailerUrl'])) && (!empty($_SESSION['trailerUrl']))) {
    $trailerUrl = '<video controls><source src="uploads/trailers/'.$_SESSION['trailerUrl'].'" type="video/mp4"></video>';
} else {
    $trailerUrl = '<img src="../assets/img/video.png" alt="">';
        
}

if ((isset($_SESSION['videoUrl'])) && (!empty($_SESSION['videoUrl']))) {
    $videoUrl = '<video controls><source src="uploads/videos/'.$_SESSION['videoUrl'].'" type="video/mp4"></video>';
} else {
    $videoUrl = '<img src="../assets/img/video.png" alt="">';
}

// SUBMIT THE VIDEO
if (($_SERVER["REQUEST_METHOD"] == "POST") && !empty($_POST)) {
    // Get User details
    $title = ($_POST['mTitle']);
    $excerpt = ($_POST['mExcerpt']);
    $genre = ($_POST['mGenre']);
    $price = ($_POST['mPrice']);
    $year = ($_POST['mYear']);
    $PG = ($_POST['mPG']);

    // First check if the same movie title exist already
    $check = $db->prepare("SELECT movie_title FROM `movies` WHERE movie_title = ?");
    $check->execute([$title]);

    if ($check->rowCount() == 0) {
        // Now enter the details
        $newMovie = $db->prepare("UPDATE `movies` SET movie_title = ?, movie_excerpt = ?, movie_genre = ?, movie_price = ?, movie_year = ?, movie_pg = ? WHERE tmp_upl_id = ?");
        $newMovie->execute([$title, $excerpt, $genre, $price, $year, $PG, 10]);
        
        if ($newMovie->rowCount() == 1) {
            $smsg = 'Video Added Successful';

            // Once upload is done, unset the sessions
            unset($_SESSION['bannerUrl']);
            unset($_SESSION['trailerUrl']);
            unset($_SESSION['videoUrl']);
            unset($_SESSION['tmp_upl_id']);

            // Change the tmp_upl_id back to 0
            $delTmpVal = $db->prepare("UPDATE `movies` SET tmp_upl_id = ? WHERE tmp_upl_id = ?");
            $delTmpVal->execute([0, 10]);

        } else if ($newMovie->rowCount() == 0) {
            $fmsg = "Failed to update video";
        }
    } else {
        $fmsg = "Record exist for this movie title. Please use a different title";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <script src="../assets/js/jquery.js"></script>
    <script src="../assets/js/style.js"></script>
    <link href="../style.css" rel="stylesheet">
</head>
<body>
    <div id="user-dashboard-page"> 
        <section>
            <div class="leftCol">
                <img src="../assets/img/logo.png" alt="">
                <hr>
                <a href="index.php">My Movies</a>
                <hr>
                <a href="users.php">Users</a>
                <hr>
                <a href="subscription.php">Subscriptions</a>
                <hr>
                <a href="movies.php" class="userNav">Movies</a>
                <hr>
                <a href="profile.php">My Profile</a>
                <hr>
                <div id="groupCallAdmin">
                    <a href="../index.php">Home Page</a>
                    <a href="../logout.php">Log Out</a>
                </div>
            </div>
            <div class="rightCol">
                <a href="movies.php"><button class="btn-primary">Go back</button></a>
                <div class="row">
                    <?php if(isset($smsg)){ ?>
                        <div class="alert alert-success" style="cursor:pointer; margin-left:auto; margin-right:auto; width: 50%;" onclick="$(this).fadeOut();"> 
                            <?php echo $smsg;?>
                        </div>
                    <?php } ?>
                    <?php if(isset($fmsg)){ ?>
                        <div class="alert alert-danger" style="cursor:pointer; margin-left:auto; margin-right:auto; width: 50%;" onclick="$(this).fadeOut();"> 
                            <?php echo $fmsg;?>
                        </div>
                    <?php } ?>
                </div>
                <form action="" method="post">
                    <div class="form-group">
                        <label for="Movie Title">Movie Title:</label>
                        <input type="text" name="mTitle" placeholder="Movie Title" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="Excerpt">Excerpt:</label>
                        <input type="text" name="mExcerpt" placeholder="Excerpt" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="Genre">Genre:</label>
                        <input type="text" name="mGenre" placeholder="Genre" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="Price">Price:</label>
                        <input type="number" name="mPrice" placeholder="Price" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="Release Year">Release Year:</label>
                        <input type="number" name="mYear" placeholder="Release year" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="Parential Guide">PG:</label>
                        <input type="number" name="mPG" placeholder="Parential Guide" class="form-control" required>
                    </div>
                    
                    <!-- Banner Upload Starts -->
                    <div class="form-group">
                        <label for="Banner">Banner:</label>
                        <div id="bannerImg" style="width: 100%;">
                            <?php echo $bannerUrl; ?> <br>
                        </div>
                        <img src="../assets/img/loader.gif" alt="" class="loader-banner">
                        <button type="button" id="uploadBanner" class="btn-primary">Upload banner</button>
                        <input type="file" name="bannerToUpload" class="bannerToUpload" style="display: none;">
                    </div>

                    <!-- Trailer Upload Starts -->
                    <div class="form-group">
                        <label for="Trailer">Trailer:</label>
                        <div id="TrailerImg" style="width: 100%;">
                            <?php echo $trailerUrl; ?> <br>
                        </div>
                        <img src="../assets/img/loader.gif" alt="" class="loader-trailer">
                        <button type="button" id="uploadTrailer" class="btn-primary">Upload trailer</button>
                        <input type="file" name="trailerToUpload" class="trailerToUpload" style="display: none;">
                    </div>
                    
                    <!-- Full Movie Upload Starts -->
                    <div class="form-group">
                        <label for="Full Movie">Full Movie:</label>
                        <div id="fullVideoImg" style="width: 100%;">
                            <?php echo $videoUrl; ?> <br>
                        </div>
                        <img src="../assets/img/loader.gif" alt="" class="loader-full">
                        <button type="button" id="uploadFullVideo" class="btn-primary">Upload full movie</button>
                        <input type="file" name="fullVideoToUpload" class="fullVideoToUpload" style="display: none;">
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn-primary btn-block">Submit Video</button>
                    </div>
                </form>
            </div>
        </section>
    </div>
    <script>
        $('.userNav').css('background', '#575664');
    </script>
</body>
</html>