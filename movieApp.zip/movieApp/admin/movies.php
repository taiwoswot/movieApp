<?php require '../connect.php';  // Database connection ?>
<?php
    /* $allMonths = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    // Select all movies
    $getMovieTitle = $db->prepare("SELECT movie_title FROM movies");
    $getMovieTitle->execute();

    $allTitle[] = $getSubscriptions->fetchAll(PDO::FETCH_ASSOC); */
?>
<!DOCTYPE html>
<head>
    <script src="../assets/js/jquery.js"></script>
    <script src="../assets/js/style.js"></script>
    <link href="../style.css" rel="stylesheet">
</head>
<body>
    <div id="user-dashboard-page"> 
        <section>
            <div class="leftCol">
                <img src="../assets/img/logo.png" alt="">
                <hr>
                <a href="index.php">My Movies</a>
                <hr>
                <a href="users.php">Users</a>
                <hr>
                <a href="subscription.php">Subscriptions</a>
                <hr>
                <a href="movies.php" class="userNav">Movies</a>
                <hr>
                <a href="profile.php">My Profile</a>
                <hr>
                <div id="groupCallAdmin">
                    <a href="../index.php">Home Page</a>
                    <a href="../logout.php">Log Out</a>
                </div>
            </div>
            <div class="rightCol">
                <div class="options">
                    <button id="allMovies" class="btn-primary">All</button>
                    <input type="text" class="inputs" placeholder="search by genre" id="genre">
                    <input type="text" class="inputs" placeholder="search by last letter" id="lastLetter">
                    <button class="goMovies btn-primary">Go</button>
                    <a href="moviesNew.php"><button class="newMovie btn-primary">New Movie</button></a>
                </div>
                <div id="movie-cont">
                    <?php
                        if ($getMovies->rowCount() > 0) {
                            $serial = 1;
                            echo '<table>
                                    <tr>
                                        <th>S/N</th>
                                        <th>Movie Title</th>
                                        <th>Price</th>
                                        <th>Genre</th>
                                        <th>Details</th>
                                    </tr>';
                                while ($row = $getMovies->fetch(PDO::FETCH_ASSOC)) {
                                    $title =  $row['movie_title'];
                                    $price =  $row['movie_price'];
                                    $genre =  $row['movie_genre'];
                                    $movie_id =  $row['movie_id'];
                            
                                    echo '<tr id="'.$movie_id.'">
                                        <td>'.$serial.'</td>
                                        <td>'.$title.'</td>
                                        <td>$'.$price.'</td>
                                        <td>'.$genre.'</td>
                                        <td class="btn-primary seeMDetails">Details</td>
                                    </tr>';

                                    $serial++;
                                }
                            echo '</table>';
                        } else {
                            echo '<h1>No movie record found</h1>';
                        }
                    ?>
                </div>
            </div>
        </section>
    </div>
    <script>
        $('.userNav').css('background', '#575664');
    </script>
</body>