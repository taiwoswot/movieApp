<?php 
session_start();
require '../connect.php';  // Database connection
if (!isset($_SESSION['role'])) {
    header('Location: ../index.php');
}

// Select subscriptions single user
$getMySubscriptions = $db->prepare("SELECT * FROM subscription WHERE subscriber_email = ?");
$getMySubscriptions->execute([$_SESSION['userEmail']]); 
?>
<!DOCTYPE html>
<head>
    <script src="../assets/js/jquery.js"></script>
    <script src="../assets/js/style.js"></script>
    <link href="../style.css" rel="stylesheet">
</head>
<body>
    <div id="user-dashboard-page"> 
        <section>
            <div class="leftCol">
            <img src="../assets/img/logo.png" alt="">
                <hr>
                <a href="#" class="userNav">My Movies</a>
                <hr>
                <a href="users.php">Users</a>
                <hr>
                <a href="subscription.php">Subscriptions</a>
                <hr>
                <a href="movies.php">Movies</a>
                <hr>
                <a href="profile.php">My Profile</a>
                <hr>
                <div id="groupCallAdmin">
                    <a href="../index.php">Home Page</a>
                    <a href="../logout.php">Log Out</a>
                </div>
            </div>
            <div class="rightCol">
                <div class="options">
                    <select name="" id="toggMovies">
                        <option value="subscribed">Subscribed</option>
                        <option value="cart">Cart</option>
                    </select>
                </div>
                <div id="tableCont">
                    <?php
                        if ($getMySubscriptions->rowCount() > 0) {
                            $serial = 1;
                            echo '<table>
                                    <tr>
                                        <th>S/N</th>
                                        <th>Movie Title</th>
                                        <th>Price</th>
                                        <th>Date</th>
                                        <th>Status</th>
                                    </tr>';
                                while ($row = $getMySubscriptions->fetch(PDO::FETCH_ASSOC)) {
                                    $id =  $row['movie_id'];
                                    $title =  $row['movie_title'];
                                    $price =  $row['price'];
                                    $date =  $row['subscribed_date'];;
                                    $puchased =  'subscribed';
                            
                                    echo '<tr id="'.$id.'">
                                        <td>'.$serial.'</td>
                                        <td>'.$title.'</td>
                                        <td>$'.$price.'</td>
                                        <td>'.$date.'</td>
                                        <td>'.$puchased.'</td>
                                    </tr>';

                                    $serial++;
                                }
                            echo '</table>';
                        } else {
                            echo '<h1>No record found</h1>';
                        }
                    ?>
                </div>
            </div>
        </section>
    </div>
    <script>
        $('.userNav').css('background', '#575664');
    </script>
</body>