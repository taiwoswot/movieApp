<?php
require '../connect.php';  // Database connection
$userEmail = $_GET['email'];

if (!isset($userEmail )) {
    header('Location: ../index.php');
}
// Select User Details
$getUserDetails = $db->prepare("SELECT * FROM users WHERE email = ?");
$getUserDetails->execute([$userEmail]); 

// Select all movies subscribed for
$getUserAllSub = $db->prepare("SELECT * FROM subscription WHERE subscriber_email = ?");
$getUserAllSub->execute([$userEmail]);
$count = $getUserAllSub->rowCount();
?>
<!DOCTYPE html>
<head>
    <script src="../assets/js/jquery.js"></script>
    <script src="../assets/js/style.js"></script>
    <link href="../style.css" rel="stylesheet">
</head>
<body>
    <div id="user-dashboard-page"> 
        <section>
            <div class="leftCol">
                <img src="../assets/img/logo.png" alt="">
                <hr>
                <a href="index.php">My Movies</a>
                <hr>
                <a href="#" class="userNav">Users</a>
                <hr>
                <a href="subscription.php">Subscriptions</a>
                <hr>
                <a href="movies.php">Movies</a>
                <hr>
                <a href="profile.php">My Profile</a>
                <hr>
                <div id="groupCallAdmin">
                    <a href="../index.php">Home Page</a>
                    <a href="../logout.php">Log Out</a>
                </div>
            </div>
            <div class="rightCol">
                <a href="users.php"><button class="btn-primary">Go Back</button></a>
                <div id="profile">
                    <?php
                        while ($row = $getUserDetails->fetch(PDO::FETCH_ASSOC)) {
                            $name =  $row['user_name'];
                            $dob =  $row['dob'];
                            $user_address =  $row['user_address'];
                            $img =  $row['pics'];

                            if (!empty($img)) {
                                $pics = '<img src="../assets/img/'.$img.'" alt="">';
                            } else {
                                $pics = '<img src="../assets/img/user.png" alt="">';
                            }
                        
                            echo '
                                <div class="img">'.$pics.'</div>
                                <form action="">
                                    <div class="form-group">
                                        <label for="Name">Name:</label>
                                        <input type="text" class="form-control" value="'.$name.'" disabled>
                                    </div>
                                    <div class="form-group">
                                        <label for="Email">Email:</label>
                                        <input type="email" class="form-control" value="'.$userEmail.'" disabled>
                                    </div>
                                    <div class="form-group">
                                        <label for="Date of Birth">Date of Birth:</label>
                                        <input type="date" class="form-control" value="'.$dob.'" disabled>
                                    </div>
                                    <div class="form-group">
                                        <label for="Address">Address:</label>
                                        <textarea class="form-control" rows="10" value="'.$user_address.'" style="width:57%;" disabled></textarea>
                                    </div>
                                    <p style="color:red;">Total movie purchased: '.$count.'</p>
                                </form>
                            ';
                        }
                    ?>
                </div>
            </div>
        </section>
    </div>
    <script>
        $('.userNav').css('background', '#575664');
    </script>
</body>