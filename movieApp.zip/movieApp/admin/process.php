<?php
session_start();
require '../connect.php';  // Database connection
$constant = $_POST['constant'];

// Function for date
$today = date('Y-m-d'); // today
function userAge($dob, $today) {
    $d1 = explode("-", $dob);
    $d2 = explode("-", $today);
    $former = $d1[0];
    $later = $d2[0];

    return ($later - $former);
}
/* ***************************************************
    // Search by all subscriber - subscription page
*****************************************************/
if ($constant == "all-movie-subscribers") {
    if ($getSubscriptions->rowCount() > 0) {
        $serial = 1;
        echo '<table>
                <tr>
                    <th>S/N</th>
                    <th>Name</th>
                    <th>Movie Title</th>
                    <th>Price</th>
                    <th>Date</th>
                    <th>Month</th>
                </th></tr>';
            while ($row = $getSubscriptions->fetch(PDO::FETCH_ASSOC)) {
                $subscriber_name =  $row['subscriber_name'];
                $title =  $row['movie_title'];
                $price =  $row['price'];
                $date =  $row['subscribed_date'];
                $month =  $row['subscribed_month'];
        
                echo '<tr>
                    <td>'.$serial.'</td>
                    <td>'.$subscriber_name.'</td>
                    <td>'.$title.'</td>
                    <td>$'.$price.'</td>
                    <td>'.$date.'</td>
                    <td>'.$month.'</td>
                </tr>';

                $serial++;
            }
        echo '</table>';
    } else {
        echo '<h1>No subscriber record found</h1>';
    }
} else
/* ***************************************************
    // Search by subscriber month - subscription page
*****************************************************/
if ($constant == "search-by-sub-month") {
    $movMonth = $_POST['movMonth'];

    $searchBySubMonth = $db->prepare("SELECT * FROM subscription WHERE subscribed_month = ?");
    $searchBySubMonth->execute([$movMonth]); 

    if ($searchBySubMonth->rowCount() > 0) {
        $sum = array();
        $serial = 1;
        echo '<table>
                <tr>
                    <th>S/N</th>
                    <th>Name</th>
                    <th>Movie Title</th>
                    <th>Price</th>
                    <th>Date</th>
                    <th>Month</th>
                </th></tr>';
            while ($row = $searchBySubMonth->fetch(PDO::FETCH_ASSOC)) {
                $subscriber_name =  $row['subscriber_name'];
                $title =  $row['movie_title'];
                $price =  $row['price'];
                $date =  $row['subscribed_date'];
                $month =  $row['subscribed_month'];
                
                echo '<tr>
                    <td>'.$serial.'</td>
                    <td>'.$subscriber_name.'</td>
                    <td>'.$title.'</td>
                    <td>$'.$price.'</td>
                    <td>'.$date.'</td>
                    <td>'.$month.'</td>
                </tr>';

                $serial++;
                $sum[] = $price;
            }
            echo '<tr><h3 style="color: green;">Total Monthly Sales for the month of <u>' . $movMonth. '</u> is: $' .array_sum($sum).'.</h3></tr>';
        echo '</table>';
    } else {
        echo '<h1>No record found</h1>';
    }
} else


/* *********************************************
    // Search by movie title - subscription page
***********************************************/
if ($constant == "search-by-movie-title") {
    $movTitle = $_POST['movTitle'];

    $searchByMovieTitle = $db->prepare("SELECT * FROM subscription WHERE movie_title = ?");
    $searchByMovieTitle->execute([$movTitle]); 

    if ($searchByMovieTitle->rowCount() > 0) {
        $sum = array();
        $serial = 1;
        echo '<table>
                <tr>
                    <th>S/N</th>
                    <th>Name</th>
                    <th>Movie Title</th>
                    <th>Price</th>
                    <th>Date</th>
                    <th>Month</th>
                </th></tr>';
            while ($row = $searchByMovieTitle->fetch(PDO::FETCH_ASSOC)) {
                $subscriber_name =  $row['subscriber_name'];
                $title =  $row['movie_title'];
                $price =  $row['price'];
                $date =  $row['subscribed_date'];
                $month =  $row['subscribed_month'];
        
                echo '<tr>
                    <td>'.$serial.'</td>
                    <td>'.$subscriber_name.'</td>
                    <td>'.$title.'</td>
                    <td>$'.$price.'</td>
                    <td>'.$date.'</td>
                    <td>'.$month.'</td>
                </tr>';

                $serial++;
                $sum[] = $price;
            }
            echo '<tr><h3 style="color: green;">Total Sales for the movie <u>' . $movTitle. '</u> is: $' .array_sum($sum).'.</h3></tr>';
        echo '</table>';
    } else {
        echo '<h1>No record found</h1>';
    }
} else

/* *********************************************
    // Search by movie subscriber name - subscription page
***********************************************/
if ($constant == "search-by-sub-name") {
    $subName = $_POST['subName'];

    $getSubscriberName = $db->prepare("SELECT * FROM subscription WHERE subscriber_name = ?");
    $getSubscriberName->execute([$subName]); 

    if ($getSubscriberName->rowCount() > 0) {
        $serial = 1;
        echo '<table>
                <tr>
                    <th>S/N</th>
                    <th>Name</th>
                    <th>Movie Title</th>
                    <th>Price</th>
                    <th>Date</th>
                    <th>Month</th>
                </th></tr>';
            while ($row = $getSubscriberName->fetch(PDO::FETCH_ASSOC)) {
                $subscriber_name =  $row['subscriber_name'];
                $title =  $row['movie_title'];
                $price =  $row['price'];
                $date =  $row['subscribed_date'];
                $month =  $row['subscribed_month'];
        
                echo '<tr>
                    <td>'.$serial.'</td>
                    <td>'.$subscriber_name.'</td>
                    <td>'.$title.'</td>
                    <td>$'.$price.'</td>
                    <td>'.$date.'</td>
                    <td>'.$month.'</td>
                </tr>';

                $serial++;
            }
        echo '</table>';
    } else {
        echo '<h1>No record found</h1>';
    }
} else
/* ********************************
    // Search by minimum age
***********************************/
if ($constant == "min") {
    $minAge = $_POST['age'];
    $getDOB = $db->prepare("SELECT dob FROM users");
    $getDOB->execute(); 
    $cols = $getDOB->fetchAll(PDO::FETCH_COLUMN);

    $matchedDate = array();
    foreach ($cols as $dob) {
        $d1 = explode("-", $dob);
        $d2 = explode("-", $today);
        $former = $d1[0];
        $later = $d2[0];
        $diff = $later - $former;

        // If the date difference is less than the minimum age, store the corresponding date value
        if ($diff >= $minAge) {
            $matchedDate[] = $dob;
        }
    }

    // Now, use the matched records to fetch details
    echo '<table>
        <tr>
            <th>S/N</th>
            <th>Pics</th>
            <th>Name</th>
            <th>Reg Date</th>
            <th>Last Login</th>
            <th>Age</th>
            <th>Details</th>
        </tr>';
        if ((count($matchedDate)) > 0) {
            $serial = 1;
            for ($i = 0; $i < count($matchedDate); $i++) {
                $getMinDOB = $db->prepare("SELECT * FROM users WHERE dob = ?");
                $getMinDOB->execute([$matchedDate[$i]]);

                $row = $getMinDOB->fetch(PDO::FETCH_ASSOC);
                $email =  $row['email'];
                $pics =  $row['pics'];
                $name =  $row['user_name'];
                $reg_date =  $row['reg_date'];
                $last_login =  $row['last_login'];
                $dob =  $row['dob'];
        
                echo '<tr id="'.$email.'">
                    <td>'.$serial.'</td>
                    <td>'.$pics.'</td>
                    <td>'.$name.'</td>
                    <td>'.$reg_date.'</td>
                    <td>'.$last_login.'</td>
                    <td>'.userAge($dob, $today).'</td>
                    <td class="btn-primary checkUser">Details</td>
                </tr>';

                $serial++;
            }
        } else {
            echo '<tr><td><h1>No user Above age ' . $minAge . ' found!</h1></td></tr>';
        }
    echo '</table>';

    // Seraching by Maximum age
} else if ($constant == "max") {
    $maxAge = $_POST['age'];
    $getDOB = $db->prepare("SELECT dob FROM users");
    $getDOB->execute(); 
    $cols = $getDOB->fetchAll(PDO::FETCH_COLUMN);

    $matchedDate = array();
    foreach ($cols as $dob) {
        $d1 = explode("-", $dob);
        $d2 = explode("-", $today);
        $former = $d1[0];
        $later = $d2[0];
        $diff = $later - $former;

        // If the date difference is less than the minimum age, store the corresponding date value
        if ($diff <= $maxAge) {
            $matchedDate[] = $dob;
        }
    }

    // Now, use the matched records to fetch details
    echo '<table>
        <tr>
            <th>S/N</th>
            <th>Pics</th>
            <th>Name</th>
            <th>Reg Date</th>
            <th>Last Login</th>
            <th>Age</th>
            <th>Details</th>
        </tr>';
        if ((count($matchedDate)) > 0) {
            $serial = 1;
            foreach ($matchedDate as $matched) {
                $getMinDOB = $db->prepare("SELECT * FROM users WHERE dob = ?");
                $getMinDOB->execute([$matched]);

                $row = $getMinDOB->fetch(PDO::FETCH_ASSOC);
                $email =  $row['email'];
                $pics =  $row['pics'];
                $name =  $row['user_name'];
                $reg_date =  $row['reg_date'];
                $last_login =  $row['last_login'];
                $dob =  $row['dob'];
        
                echo '<tr id="'.$email.'">
                    <td>'.$serial.'</td>
                    <td>'.$pics.'</td>
                    <td>'.$name.'</td>
                    <td>'.$reg_date.'</td>
                    <td>'.$last_login.'</td>
                    <td>'.userAge($dob, $today).'</td>
                    <td class="btn-primary checkUser">Details</td>
                </tr>';

                $serial++;
            }
        } else {
            echo '<tr><td><h1>No user Below age ' . $maxAge . ' found!</h1></td></tr>';
        }
    echo '</table>';
} else if ($constant == "all-user") {
    if ($getUsers->rowCount() > 0) {
        $serial = 1;
        echo '<table>
                <tr>
                    <th>S/N</th>
                    <th>Pics</th>
                    <th>Name</th>
                    <th>Reg Date</th>
                    <th>Last Login</th>
                    <th>Age</th>
                    <th>Details</th>
                </tr>';
            while ($row = $getUsers->fetch(PDO::FETCH_ASSOC)) {
                $email =  $row['email'];
                $pics =  $row['pics'];
                $name =  $row['user_name'];
                $reg_date =  $row['reg_date'];
                $last_login =  $row['last_login'];
                $dob =  $row['dob'];
        
                echo '<tr id="'.$email.'">
                    <td>'.$serial.'</td>
                    <td>'.$pics.'</td>
                    <td>'.$name.'</td>
                    <td>'.$reg_date.'</td>
                    <td>'.$last_login.'</td>
                    <td>'.userAge($dob, $today).'</td>
                    <td class="btn-primary checkUser">Details</td>
                </tr>';

                $serial++;
            }
        echo '</table>';
    } else {
        echo '<h1>No User found</h1>';
    }
} else if ($constant == "all-movies") {
    if ($getMovies->rowCount() > 0) {
        $serial = 1;
        echo '<table>
                <tr>
                    <th>S/N</th>
                    <th>Movie Title</th>
                    <th>Price</th>
                    <th>Genre</th>
                    <th>Details</th>
                </tr>';
            while ($row = $getMovies->fetch(PDO::FETCH_ASSOC)) {
                $title =  $row['movie_title'];
                $price =  $row['movie_price'];
                $genre =  $row['movie_genre'];;
        
                echo '<tr>
                    <td>'.$serial.'</td>
                    <td>'.$title.'</td>
                    <td>$'.$price.'</td>
                    <td>'.$genre.'</td>
                    <td class="btn-primary">Details</td>
                </tr>';

                $serial++;
            }
        echo '</table>';
    } else {
        echo '<h1>No movie record found</h1>';
    }
} else if ($constant == "genre") {
    /* ********************************
        Select movies by Genre
    ***********************************/
    $genre = $_POST['gen'];
    $getMovieByGenre = $db->prepare("SELECT * FROM movies WHERE movie_genre = ?");
    $getMovieByGenre->execute([$genre]); 

    if ($getMovieByGenre->rowCount() > 0) {
        $serial = 1;
        echo '<table>
                <tr>
                    <th>S/N</th>
                    <th>Movie Title</th>
                    <th>Price</th>
                    <th>Genre</th>
                    <th>Details</th>
                </tr>';
            while ($row = $getMovieByGenre->fetch(PDO::FETCH_ASSOC)) {
                $title =  $row['movie_title'];
                $price =  $row['movie_price'];
                $genre =  $row['movie_genre'];
                $movie_id =  $row['movie_id'];
        
                echo '<tr id="'.$movie_id.'">
                    <td>'.$serial.'</td>
                    <td>'.$title.'</td>
                    <td>$'.$price.'</td>
                    <td>'.$genre.'</td>
                    <td class="btn-primary seeMDetails">Details</td>
                </tr>';

                $serial++;
            }
        echo '</table>';
    } else {
        echo '<h1>No movie record found</h1>';
    }
} else if ($constant == "lastLetter") {
    /* ********************************
        Select movies by Last Letter
    ***********************************/
    $lastL = $_POST['lastL'];
    $getMovieByLastL = $db->prepare("SELECT movie_title FROM movies");
    $getMovieByLastL->execute(); 
    $cols = $getMovieByLastL->fetchAll(PDO::FETCH_COLUMN);

    $matchedTitle = array();
    foreach ($cols as $eachTitle) {
        $LastLet = substr($eachTitle, -1);

        // If the last letter to search for match the last letter of the movie title, store the corresponding title value
        if ($LastLet == $lastL) {
            $matchedTitle[] = $eachTitle;
        }
    }

    if ((count($matchedTitle)) > 0) {
        $serial = 1;
        echo '<table>
            <tr>
                <th>S/N</th>
                <th>Movie Title</th>
                <th>Price</th>
                <th>Genre</th>
                <th>Details</th>
            </tr>';

            for ($i = 0; $i < count($matchedTitle); $i++) {
                $getMatched = $db->prepare("SELECT * FROM movies WHERE movie_title = ?");
                $getMatched->execute([$matchedTitle[$i]]);
                
                $row = $getMatched->fetch(PDO::FETCH_ASSOC);
                $title =  $row['movie_title'];
                $price =  $row['movie_price'];
                $genre =  $row['movie_genre'];
                $movie_id =  $row['movie_id'];
        
                echo '<tr id="'.$movie_id.'">
                    <td>'.$serial.'</td>
                    <td>'.$title.'</td>
                    <td>$'.$price.'</td>
                    <td>'.$genre.'</td>
                    <td class="btn-primary seeMDetails">Details</td>
                </tr>';

                $serial++;
            }
        echo '</table>';
    } else {
        echo '<h1>No movie title with last letter '.$lastL.' found</h1>';
    }
}
?>