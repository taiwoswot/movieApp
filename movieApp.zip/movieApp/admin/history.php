<?php require '../connect.php';  // Database connection ?>
<!DOCTYPE html>
<head>
    <script src="../assets/js/jquery.js"></script>
    <script src="../assets/js/style.js"></script>
    <link href="../style.css" rel="stylesheet">
</head>
<body>
    <div id="user-dashboard-page"> 
        <section>
            <div class="leftCol">
                <img src="../assets/img/logo.png" alt="">
                <hr>
                <a href="index.php">My Movies</a>
                <hr>
                <a href="users.php">Users</a>
                <hr>
                <a href="subscription.php">Subscriptions</a>
                <hr>
                <a href="movies.php">Movies</a>
                <hr>
                <a href="profile.php">My Profile</a>
                <hr>
                <a href="#" class="userNav">History</a>
                <hr>
                <div id="groupCallAdmin">
                    <a href="../index.php">Home Page</a>
                    <a href="../logout.php">Log Out</a>
                </div>
            </div>
            <div class="rightCol">
                <div class="options">
                    <select name="" id="hisOpt" class="btn-primary">
                        <option value="all">All</option>
                        <option value="title">Movie title</option>
                        <option value="date">Date</option>
                    </select>
                </div>
                <div class="table">
                    <?php
                        if ($getSubscriptions->rowCount() > 0) {
                            $serial = 1;
                            echo '<table>
                                    <tr><th>
                                        <td>S/N</td>
                                        <td>Movie Title</td>
                                        <td>Price</td>
                                        <td>Date</td>
                                        <td>Status</td>
                                    </th></tr>';
                                while ($row = $getSubscriptions->fetch(PDO::FETCH_ASSOC)) {
                                    $id =  $row['movie_id'];
                                    $title =  $row['movie_title'];
                                    $price =  $row['price'];
                                    $date =  $row['subscribed_date'];;
                                    $puchased =  'subscribed';
                            
                                    echo '<tr id="'.$id.'">
                                        <td>'.$serial.'</td>
                                        <td>'.$title.'</td>
                                        <td>'.$price.'</td>
                                        <td>'.$date.'</td>
                                        <td>'.$puchased.'</td>
                                    </tr>';

                                    $serial++;
                                }
                            echo '</table>';
                        } else {
                            echo '<h1>No record found</h1>';
                        }
                    ?>
                </div>
            </div>
        </section>
    </div>
    <script>
        $('.userNav').css('background', '#575664');
    </script>
</body>