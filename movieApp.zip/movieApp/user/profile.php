<?php
session_start();
require '../connect.php';  // Database connection
$userEmail = $_SESSION['userEmail'];

if (!isset($userEmail)) {
    header('Location: ../index.php');
}
// Select User Details
$getUserDetails = $db->prepare("SELECT * FROM users WHERE email = ?");
$getUserDetails->execute([$userEmail]); 
?>
<!DOCTYPE html>
<head>
    <script src="../assets/js/jquery.js"></script>
    <script src="../assets/js/style.js"></script>
    <link href="../style.css" rel="stylesheet">
</head>
<body>
    <div id="user-dashboard-page"> 
        <section>
            <div class="leftCol">
                <img src="../assets/img/logo.png" alt="">
                <hr>
                <a href="index.php">My Movies</a>
                <hr>
                <a href="#" class="userNav">My Profile</a>
                <hr>
                <div id="groupCallAdmin">
                    <a href="../index.php">Home Page</a>
                    <a href="../logout.php">Log Out</a>
                </div>
            </div>
            <div class="rightCol">
                <div id="profile">
                    <?php
                        while ($row = $getUserDetails->fetch(PDO::FETCH_ASSOC)) {
                            $name =  $row['user_name'];
                            $dob =  $row['dob'];
                            $user_address =  $row['user_address'];
                            $img =  $row['pics'];

                            if (!empty($img)) {
                                $pics = '<img src="../assets/img/'.$img.'" alt="">';
                            } else {
                                $pics = '<img src="../assets/img/user.png" alt="">';
                            }
                        
                            echo '
                                <div class="img">'.$pics.' <a href="#">change image</a></div>
                                <form action="">
                                    <div class="form-group">
                                        <label for="Name">Name:</label>
                                        <input type="text" class="form-control" id="name" value="'.$name.'" disabled>
                                        <span class="edit">edit</span> <span class="done">done</span>
                                    </div>
                                    <div class="form-group">
                                        <label for="Email">Email:</label>
                                        <input type="email" class="form-control" id="email" value="'.$userEmail.'" disabled>
                                        <span class="edit">edit</span> <span class="done">done</span>
                                    </div>
                                    <div class="form-group">
                                        <label for="Date of Birth">Date of Birth:</label>
                                        <input type="date" class="form-control" id="dob" value="'.$dob.'" disabled>
                                        <span class="edit">edit</span> <span class="done">done</span>
                                    </div>
                                    <div class="form-group">
                                        <label for="Address">Address:</label>
                                        <textarea class="form-control" id="address" rows="10" value="'.$user_address.'" style="width:57%;" disabled></textarea>
                                        <span class="edit">edit</span> <span class="done">done</span>
                                    </div>
                                    <div class="form-group dPwd">
                                        <label for="Password">Password:</label>
                                        <input type="password" id="pwd" placeholder="your password" class="form-control" disabled>
                                        <span class="edit-pwd">edit</span>
                                    </div>
                                    <div class="change-password">
                                        <div class="form-group">
                                            <label for="Old Password">Old Password:</label>
                                            <input type="password" id="old-pwd" placeholder="old password" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for="New Password">New Password:</label>
                                            <input type="password" id="new-pwd" placeholder="new password" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for="Confirm New Password">Confirm New Password:</label>
                                            <input type="password" id="confirm-new-pwd" placeholder="confirm new password" class="form-control">
                                            <span class="cancel-pwd">cancel</span> <span class="done">done</span>
                                        </div>
                                    </div>
                                </form>
                            ';
                        }
                    ?>
                </div>
            </div>
        </section>
    </div>
    <script>
        $('.userNav').css('background', '#575664');
    </script>
</body>