<?php
session_start();
require '../connect.php';  // Database connection
$constant = $_POST['constant'];

/* *******************************************
    // Toggle subscribed or cart view for use
*********************************************/
if ($constant == "user-subscribed-or-cart") {
    $togView = $_POST['togView'];
    
    // Show list of subscribed movies
    if ($togView == 'subscribed') {
        // Select subscriptions this user
        $getMySubscriptions = $db->prepare("SELECT * FROM subscription WHERE subscriber_email = ?");
        $getMySubscriptions->execute([$_SESSION['userEmail']]); 

        if ($getMySubscriptions->rowCount() > 0) {
            $serial = 1;
            echo '<table>
                    <tr>
                        <th>S/N</th>
                        <th>Movie Title</th>
                        <th>Price</th>
                        <th>Date</th>
                        <th>Status</th>
                    </tr>';
                while ($row = $getMySubscriptions->fetch(PDO::FETCH_ASSOC)) {
                    $id =  $row['movie_id'];
                    $title =  $row['movie_title'];
                    $price =  $row['price'];
                    $date =  $row['subscribed_date'];;
                    $puchased =  'subscribed';
            
                    echo '<tr id="'.$id.'">
                        <td>'.$serial.'</td>
                        <td>'.$title.'</td>
                        <td>$'.$price.'</td>
                        <td>'.$date.'</td>
                        <td>'.$puchased.'</td>
                    </tr>';

                    $serial++;
                }
            echo '</table>';
        } else {
            echo '<div>No record found</div>';
        }
    // Show list of cart movies
    } else if ($togView == 'cart') {
        // Select cart movies this user
        $getMyCart = $db->prepare("SELECT * FROM cart WHERE user_email = ?");
        $getMyCart->execute([$_SESSION['userEmail']]); 

        if ($getMyCart->rowCount() > 0) {
            $serial = 1;
            echo '<table>
                    <tr>
                        <th>S/N</th>
                        <th>Movie Title</th>
                        <th>Price</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>';
                while ($row = $getMyCart->fetch(PDO::FETCH_ASSOC)) {
                    $id =  $row['movie_id'];
                    $title =  $row['movie_title'];
                    $price =  $row['price'];
                    $date =  $row['cart_date'];;
                    $incart =  'In-cart';
            
                    echo '<tr id="'.$id.'">
                        <td>'.$serial.'</td>
                        <td>'.$title.'</td>
                        <td>$'.$price.'</td>
                        <td>'.$date.'</td>
                        <td>'.$incart.'</td>
                        <td class="btn-warning">Buy Now</td>
                    </tr>';

                    $serial++;
                }
            echo '</table>';
        } else {
            echo '<div>No record found</div>';
        }
    }
}
?>